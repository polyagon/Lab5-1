package org.example.Enums;

public enum FOODStatus {
    RAW,
    DONE,
    DEAD;
}

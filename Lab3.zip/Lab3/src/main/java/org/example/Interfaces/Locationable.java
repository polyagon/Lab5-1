package org.example.Interfaces;

import org.example.Locations.Location;

public interface Locationable {
    public Location getLocation();
    public void setLocation(Location loc);
}

package org.example.Items;

import org.example.Enums.ITEMStatus;
import org.example.Excaptions.FailedExcapiton;
import org.example.Persons.Person;

public abstract class AbstractItem {
    private String name;
    private ITEMStatus status;

    public String getName(){
        return name;
    }

    public AbstractItem(String name, ITEMStatus stat){
        this.name = name;
        this.status = stat;
    }

    public void setName(String name){
        this.name = name;
    }

    public ITEMStatus getStatus(){
        return status;
    }
    public void setStatus(ITEMStatus stat){
        this.status = stat;
    }
    public boolean checkActive(){
        return status == ITEMStatus.ACTIVE;
    }

    public abstract void use(Person p) throws FailedExcapiton;
}

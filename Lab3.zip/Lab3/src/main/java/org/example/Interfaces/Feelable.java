package org.example.Interfaces;

public interface Feelable {
    public void scared(String item);
}

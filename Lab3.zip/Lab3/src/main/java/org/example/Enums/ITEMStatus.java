package org.example.Enums;

public enum ITEMStatus {
    ACTIVE,
    BROKEN,
    DESTROYED;
}

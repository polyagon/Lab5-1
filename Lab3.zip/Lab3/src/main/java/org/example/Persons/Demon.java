package org.example.Persons;

import org.example.Items.AbstractItem;
import org.example.Items.Item;
import org.example.Locations.AbstractLocation;
import org.example.Locations.Location;

public class Demon extends Person{
    Location nowLocation;

    public Demon(String name, int age, int height){
        this.setAge(age);
        this.setHeight(height);
        this.setName(name);
    }

    public void scare(Person p){
        System.out.println(this.getName() + " scare a person " + p.getName());
    }

    @Override
    public String toString(){
        return "Class: Demon;\n name: " + this.getName() + ";\n age: " + this.getAge() + ";\n height: " + this.getHeight();
    }
    @Override
    public int hashCode() {
        int hash = this.getName().hashCode();
        hash += this.getAge();
        hash += this.nowLocation.hashCode();
        hash += this.getHeight();
        return hash;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || this.getClass() != o.getClass()) return false;

        Demon check = (Demon) o;
        return this.hashCode() == check.hashCode();
    }
}

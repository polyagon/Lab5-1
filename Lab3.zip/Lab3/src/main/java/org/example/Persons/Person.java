package org.example.Persons;

import org.example.Excaptions.FailedExcapiton;
import org.example.Items.AbstractItem;
import org.example.Items.Item;
import org.example.Locations.AbstractLocation;
import org.example.Locations.Location;;import java.util.ArrayList;

public abstract class Person {
    private int age;
    private int height;
    private String name;
    public Location nowLocation = null;

    public ArrayList<Item> own = new ArrayList<>();
    public ArrayList<Location> own_loc = new ArrayList<>();
    public void addOwn(Item item){
        this.own.add(item);
    }
    public void removeOwn(Item item){
        this.own.add(item);
    }
    public void addOwn(Location loc){
        this.own_loc.add(loc);
    }
    public void removeOwn(Location loc){
        this.own_loc.add(loc);
    }



    public Location getNowLocation(){
        return nowLocation;
    }
    public void setNowLocation(Location loc){
        this.nowLocation = loc;
    }


    public int getAge(){
        return age;
    }
    public int getHeight(){
        return height;
    }

    public void setAge(int age){
        this.age = age;
    }

    public void setHeight(int height){
        this.height = height;
    }

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void use(Item item) throws FailedExcapiton {
        item.use(this);
    }

    public void watch(AbstractLocation loc){
        System.out.println(this.getName() + " watch to " + loc.getName());
    }

    public void moveTo(Location loc){
        this.nowLocation = loc;
        System.out.println(this.getName() + " move to" + loc.getName());
    }

    public String moveTo(Location loc, AbstractItem item){
        this.nowLocation = loc;
        return this.getName() + " move to" + loc.getName();
    }

    public void create(Location loc){
        nowLocation = loc;
        System.out.println(this.getName() + " created " + loc.getName());
    }
    public void create(Item item){
        System.out.println(this.getName() + " created " + item.getName());
    }
    public void find(Item item){
        item.setOwner(this);
        System.out.println(this.getName() + " find " + item.getName());
    }
    public String find(Location loc){
        loc.setOwner(this);
        return this.getName() + "find " + loc.getName();
    }


}

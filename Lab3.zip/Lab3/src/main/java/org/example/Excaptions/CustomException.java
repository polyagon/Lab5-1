package org.example.Excaptions;

import java.io.IOException;

public class CustomException extends IOException {
    public CustomException(String message){
        super("Error : " + message);
    }

}

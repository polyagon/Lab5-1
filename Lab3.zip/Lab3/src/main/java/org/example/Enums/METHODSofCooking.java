package org.example.Enums;

public enum METHODSofCooking {
    BOILING,
    FRYING,
    BAKEING,
    NOTHING;
}

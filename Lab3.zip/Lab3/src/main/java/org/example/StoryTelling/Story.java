package org.example.StoryTelling;

import org.example.Enums.FOODStatus;
import org.example.Enums.ITEMStatus;
import org.example.Enums.METHODSofCooking;
import org.example.Excaptions.CustomException;
import org.example.Excaptions.FailedExcapiton;
import org.example.Items.Fire;
import org.example.Items.Food;
import org.example.Items.Item;
import org.example.Locations.Location;
import org.example.Persons.Demon;
import org.example.Persons.Human;

public class Story {

    public Story(){}

    public void defaultStory() throws CustomException, FailedExcapiton {
        Human hero1 = new Human("John", 22, 175);
        Location home = new Location("Home", 0.5, hero1);
        Fire fire = new Fire("Cave", ITEMStatus.ACTIVE,0.6, home);
        fire.makeSmoke(true);
         hero1.scared(fire.getSmoke()) ;

        Food bread = new Food("Bread",  1200, FOODStatus.RAW, new METHODSofCooking[]{METHODSofCooking.BAKEING, METHODSofCooking.FRYING, METHODSofCooking.BOILING});
        hero1.cook(bread, METHODSofCooking.BAKEING);

        Food beef = new Food("Beef", 4000, FOODStatus.RAW, new METHODSofCooking[]{METHODSofCooking.BOILING, METHODSofCooking.FRYING, METHODSofCooking.BAKEING});
        hero1.cook(beef, METHODSofCooking.BOILING);

        Location forest = new Location("Forest", 0.3);
        hero1.moveTo(forest);

        Item brancheas = new Item("Little branches", ITEMStatus.ACTIVE, forest);
        hero1.burn(fire, brancheas);
        Item coal = new Item("Coal", ITEMStatus.ACTIVE, forest);
        hero1.create(coal);

        hero1.moveTo(home, coal);
        fire.makeSmoke(false);

        hero1.moveTo(forest);
        Location bash = new Location("A Bush", 0.2, forest);
        hero1.watch(bash);
        Location cave = new Location("Cave", 0.2);
        hero1.find(cave);
        hero1.moveTo(cave);

        Demon demon = new Demon("Satan", 666, 200);
        demon.scare(hero1);
        hero1.scared(demon.getName());
        hero1.moveTo(forest);
    }
}
